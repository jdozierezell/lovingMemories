import { Link } from "gatsby"
import PropTypes from "prop-types"
import React, { useState, useEffect } from "react"
import { StaticImage } from "gatsby-plugin-image"
import { isLoggedIn, getCurrentUser, logout } from "../../utils/auth"

import { Menu, Dropdown } from 'antd';
import { AiFillInfoCircle } from 'react-icons/ai';

import { RiLoginCircleLine } from 'react-icons/ri'
import { navigate } from "gatsby"

import { useStateMachine } from "little-state-machine";
import updateAction from "../../utils/updateAction";

import { handleAPIPost, handleAPIFetch } from "../../utils/auth";

import { useForm } from "react-hook-form";

function Main({ siteTitle, isLanding }) { 



  let userDetails = {};

  const [ isUserLoggedIn, setIsUserLoggedIn ] = useState(isLoggedIn)

  const [memoryNotification, setMemoryNotification] = useState([])
  const [memoryNotificationRead, setMemoryNotificationRead] = useState([])
  const { state, actions } = useStateMachine({ updateAction });

    const { watch, register, getValues, handleSubmit, formState: {errors, isValid} } = useForm({
        mode:"onChange",
        defaultValues:  state.data
    });

    const values = getValues();
    let currentUserName = '';

    const onSubmit = data => {
        actions.updateAction(data);
        navigate("/app/in-memory-of");
    };
    if (values.user != null) {
        if(values.user.email != null) {
            currentUserName = values.user.email;
        }
    }

    const menu = (

    <Menu>
        <Menu.Item style={{padding:"10px 30px 0 30px"}} key="0">
            <span className="pointer-events-none text-xs text-gray-400">Logged in as:</span>
            <p className="pointer-events-none text-sm text-gray-700">
                {currentUserName}
            </p>
        </Menu.Item>
        <Menu.Divider />
        <Menu.Item style={{padding:"10px 30px"}} key="1">
            <Link to="/app/your-memories">Your memories</Link>
        </Menu.Item>
        <Menu.Item style={{padding:"10px 30px", position:"relative"}} key="2">
        <Link to="/app/notifications">
            Notifications
            {(memoryNotification == true) ? (
                <span className='has-notification dropdown-nav'></span>
            ) : (
                <></>
            )}
            </Link>
        </Menu.Item>  
        <Menu.Item style={{padding:"10px 30px"}} key="3">
            <Link to="/app/account-settings">Account settings</Link>

        </Menu.Item>
        <Menu.Divider />
        <Menu.Item onClick={() => handleSignOut(callback)} style={{padding:"10px 30px"}} key="4">Log out</Menu.Item>
        <Menu.Divider />
        <Menu.Item style={{padding:"10px 30px 0 30px"}} key="5">
            <Link to="https://afsp.org/" target="_blank">
            <p className="pointer-events-none text-sm text-gray-700">
                If you are experiencing a crisis <br/><span className="pointer-events-none text-sm text-blue-700">Please get immediate help</span>
            </p>
            </Link>
        </Menu.Item>
    </Menu> 
  );

  const handleSignOut = () => {
    logout(callback)
    navigate("/");
    
    let data = [];
    data.access_token="";
    data.name="";
    data.loving=""; 
    data.cover_image=null;            
    data.photos=[];
    data.description="";
    data.favorites=[];
    data.special_dates=[];
    data.reminder=0;
    data.friends=[];
    data.id=null; 
    data.user_id=null;
    data.status_id=null;
    data.active=null;
    data.visible_type="public";
    data.user={
      name:'',
      email:'',
      all_memory_reminder:0,
      receive_afsp_resources:0
    };
    data.theme_color="";
    data.thumbnail=""; 
      data.prevFrom = 0;    

    actions.updateAction(data);

    window.location.reload();
    
  }
  
  const callback = () => {

    setIsUserLoggedIn(isLoggedIn);

  }

    const handleNotificationReadSuccess = data => {
        console.log(data);
        setMemoryNotification(data.show_notification);
    }

    const handleNotificationReadErrors = data => {
        alert("error");
    }

    useEffect(() => {
        let details = {}
        if(state.data != undefined) {
            handleAPIPost('user/check/new/notifications', details, state.data.auth_token, handleNotificationReadSuccess, handleNotificationReadErrors);
        }

    }, []);

  return (

    <div className="absolute w-full z-40 bg-white lg:bg-transparent  lg:shadow-none header-nav">

      {(isLanding) ? (<></>) : (

        <div className={`flex items-center justify-between p-5 ${isUserLoggedIn ? "bg-white " : ""}`}>

          <div>
            <Link to="/">           
             <StaticImage src="../../svg/logo.svg" className="cursor-pointer" placeholder="white" alt="logo" />
             </Link>
          </div>

          {(isUserLoggedIn) ? ( <div className="relative w-full top-0 pointer-events-none hidden lg:block"> 
                <div className="flex gap-10 items-center justify-center mx-auto pointer-events-auto header-nav">

                    <div className="text-lg font-bold ">
                      <Link to="/app/your-memories">            
                        <span className="text-gray-400 text-sm">
                          Memories
                        </span>            

                      </Link>
                    </div>
                    <div className="text-lg font-bold ">
                      <Link to="/app/notifications">            
                        <span className="text-gray-400 text-sm relative">
                          Notifications
                            {(memoryNotification == true) ? (
                                <span className='has-notification'></span>
                            ) : (
                                <></>
                            )}
                        </span>            
                      </Link>
                    </div>
                    <div className="text-lg font-bold ">
                    
                     <Link to="/app/account-settings">
                        <span className="text-gray-400 text-sm">
                          Account Settings
                        </span>                    
                        </Link>
                    
                    </div>
                  </div>  
          </div>) :(
            <></>
          )}

         

          <div style={{width:'233px'}} className="flex items-center justify-end">

            {(isUserLoggedIn) ? (

            <Dropdown overlay={menu} trigger={['click']}>
              <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
              <AiFillInfoCircle size={50} />
              </a>
            </Dropdown>

            ) : (
            <Link to="/app/login">
              <span>
                <button 
                className="md:hidden flex text-center btn-signin px-0 py-2 w-30 md:w-auto text-xs md:text-lg leading-none bg-white text-blue-500 border border-blue-500 rounded-full hover:border-transparent hover:text-white hover:bg-blue-500 lg:mt-0"
                >
                <RiLoginCircleLine className="mx-auto" size={25} />
                </button>
                 <button
                className="hidden btn-signin md:inline-block px-8 py-2 w-20 md:w-auto text-xs md:text-lg leading-none bg-white text-blue-500 border border-blue-500 rounded-full hover:border-transparent hover:text-white hover:bg-blue-500 lg:mt-0"
                >
                <span>Sign In</span>
                </button>
              </span>              
            </Link>
            )}

          </div>

        </div>

      )}

    </div>

    


  )
}

Main.propTypes = {
  siteTitle: PropTypes.string,
}

Main.defaultProps = {
  siteTitle: ``,
}

export default Main
