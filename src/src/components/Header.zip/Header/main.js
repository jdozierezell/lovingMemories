import { Link } from "gatsby"
import PropTypes from "prop-types"
import React, { useState, useEffect } from "react"
import { StaticImage } from "gatsby-plugin-image"
import { isLoggedIn, logout } from "../../utils/auth"

function Main({ siteTitle }) {
  const [isExpanded, toggleExpansion] = useState(false)
  const [ isUserLoggedIn, setIsUserLoggedIn ] = useState(isLoggedIn)


  const handleSignOut = () => {
    logout(callback)
  }
  

  const callback = () => {
    setIsUserLoggedIn(isLoggedIn)

  }

    useEffect(() => {
   

    console.log(siteTitle);
    }, []);

  
  return (
    <nav className="relative lg:absolute w-full flex md:flex-wrap items-center justify-between p-6  bg-transparent z-10">
      <div className="flex items-center">
        <span>
          <StaticImage  src="../../svg/logo.svg" placeholder="white" alt="logo" />
        </span>
      </div>
      <div className="block lg:hidden">
        <button
          onClick={() => toggleExpansion(!isExpanded)}
          className="flex items-center px-3 py-2 text-white border border-white rounded hover:text-white hover:border-white"
        >
          <svg
            className="w-3 h-3 fill-current"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <title>Menu</title>
            <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
          </svg>
        </button>
      </div>
      <div
        className="flex items-center justify-items-center w-auto"
      >
        
        <div>

          {(isUserLoggedIn) ? (

          <button
            onClick={() => handleSignOut(callback)}
            className="inline-block px-8 py-2 w-20 md:w-auto text-xs md:text-lg leading-none bg-white text-blue-500 border border-blue-500 rounded-full hover:border-transparent hover:text-white hover:bg-blue-500 lg:mt-0"
          >
            Sign Out
          </button>          

          ) : (

  <Link to="/app/login">
          <button
            className="btn-signin inline-block px-8 py-2 w-20 md:w-auto text-xs md:text-lg leading-none bg-white text-blue-500 border border-blue-500 rounded-full hover:border-transparent hover:text-white hover:bg-blue-500 lg:mt-0"
          >
            Sign In
          </button>
          </Link>
          )}

          


        </div>
      </div>
    </nav>
  )
}

Main.propTypes = {
  siteTitle: PropTypes.string,
}

Main.defaultProps = {
  siteTitle: ``,
}

export default Main
